from django.urls import path
from . import views

urlpatterns = [
    path('',views.Signup, name='index'),   
    path('login',views.Login, name='login'),

    path('personal',views.Personal_view, name='personal'),
    path('summary/<int:personal_id>',views.Summary_view, name='summary'),
    path('skills/<int:personal_id>',views.Skills_view, name='skills'),
    path('projects/<int:personal_id>',views.Projects_view, name='projects'),
    path('education/<int:personal_id>',views.Education_view, name='education'),
    path('experience/<int:personal_id>',views.Experience_view, name='experience'),
    path('extras/<int:personal_id>',views.Extras_view, name='extras'),
    path('final_view/<int:personal_id>',views.finish_view, name='final_view'),
]
